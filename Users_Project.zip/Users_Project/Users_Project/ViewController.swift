//
//  ViewController.swift
//  Users_Project
//
//  Created by Sahil Saharkar on 10/08/22.
//

import UIKit

class ViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{
   
    @IBOutlet weak var tableView: UITableView!
    var contactList = [Contact]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set TableView Delegates
        tableView.delegate = self
        tableView.dataSource = self
        
        // API Call and JSON Parsing
        parsingJson {
            self.tableView.reloadData()
        }
    }
    
    func parsingJson(completed: @escaping() -> ()) {

        let url = URL(string: "https://jsonplaceholder.typicode.com/users")
        
       URLSession.shared.dataTask(with: url!) { data, response, error in
            if error == nil, data != nil{

                do {
                    self.contactList = try JSONDecoder().decode([Contact].self, from: data!)
                    DispatchQueue.main.async {
                        completed()
                    }
                } catch {
                    print("Error took place \(error).")
                }
            }
        }
        .resume()
    }
    
    // TableView Delegate Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.textLabel?.text = contactList[indexPath.row].name.capitalized
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "showDetails", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? ContactDetailsViewController{
            destination.contact = contactList[(tableView.indexPathForSelectedRow?.row)!]
        }
    }
    
    
    
    
    
}

