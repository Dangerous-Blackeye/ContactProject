//
//  ContactDetailsViewController.swift
//  Users_Project
//
//  Created by Sahil Saharkar on 10/08/22.
//

import UIKit

class ContactDetailsViewController: UIViewController {

    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblPhone: UILabel!
    @IBOutlet weak var lblWebsite: UILabel!
    @IBOutlet weak var lblCity: UILabel!
    @IBOutlet weak var lblCompany: UILabel!
    
    var contact:Contact?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Collecting Full Address
        let str = (contact?.address.street ?? "") + (contact?.address.suite ?? "") + (contact?.address.city ?? "") + (contact?.address.zipcode ?? "")
        
        lblName.text = contact?.name
        lblEmail.text = contact?.email
        lblPhone.text = contact?.phone
        lblWebsite.text = contact?.website
        lblCity.text = str
        lblCompany.text = contact?.company.name
        
      }
    
}
